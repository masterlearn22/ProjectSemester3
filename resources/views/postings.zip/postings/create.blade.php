@extends('index')

@section('content')
<div class="container">
    <h1>Buat Postingan Baru</h1>

    <form action="{{ route('postings.store') }}" method="POST">
        @csrf
        <div class="form-group">
            <label for="message_text">Isi Postingan:</label>
            <textarea name="message_text" class="form-control" rows="3" required></textarea>
        </div>

        <div class="form-group">
            <label for="message_gambar">Upload Gambar (Opsional):</label>
            <input type="text" name="message_gambar" class="form-control">
        </div>

        <button type="submit" class="btn btn-primary mt-2">Buat Postingan</button>
    </form>
</div>
@endsection
