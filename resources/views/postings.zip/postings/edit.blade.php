@extends('index')

@section('content')
<div class="container">
    <h1>Edit Postingan</h1>

    <form action="{{ route('postings.update', $post->posting_id) }}" method="POST">
        @csrf
        @method('PUT')

        <div class="form-group">
            <label for="sender">Nama Pengirim:</label>
            <input type="text" name="sender" class="form-control" value="{{ $post->sender }}" disabled>
        </div>

        <div class="form-group">
            <label for="message_text">Isi Postingan:</label>
            <textarea name="message_text" class="form-control" rows="3" required>{{ $post->message_text }}</textarea>
        </div>

        <div class="form-group">
            <label for="message_gambar">Upload Gambar (Opsional):</label>
            <input type="text" name="message_gambar" class="form-control" value="{{ $post->message_gambar }}">
        </div>

        <button type="submit" class="btn btn-primary mt-2">Update Postingan</button>
    </form>
</div>
@endsection
